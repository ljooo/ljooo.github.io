$('#convert').click(function() {
	var far = $('#far').val()
	var cel = $('#cel').val()
	$('#far').val((cel*1.8)+32);
	$('#cel').val((far-32)/1.8);
})


$('#reset').click(function() {
	$('#reset').html(reset)
	var reset = 0;
	$('#far').val = reset
	$('#cel').val = reset
})
